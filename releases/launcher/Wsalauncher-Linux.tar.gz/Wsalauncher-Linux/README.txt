Wsalauncher (Linux)
===================
1. Double-click Wsalauncher or run: ./run.sh
2. Needs system Qt6 (Widgets + Network) and Java 25+ for the game.
3. No source / CMake required — binary is in app/

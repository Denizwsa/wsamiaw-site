Wsalauncher (Linux)
===================
1. Double-click Wsalauncher or run: ./run.sh
2. Needs system Qt6 (Widgets + Network). Java 25+ only for Install/Play (Minecraft).
3. HWID is computed inside the launcher (no Java needed for Account tab).
4. No source / CMake required — binary is in app/
